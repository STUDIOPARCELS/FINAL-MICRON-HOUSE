# Messages to send

Replace [Name]. Nothing else needs editing.

## Email

**Subject:** An invitation for Optimus + Cybercab

Hi [First name],

I cannot overstate how excited I am about the ways Optimus and Cybercab will reshape how we live, work, travel and gather.

I would be delighted to welcome Tesla into Warm Springs House, my 1906 house in Boise, where Tesla engineers live and work alongside Optimus and Cybercab: the proving ground for the first autonomous corporate residence and entertainment hub.

[Warm Springs House - Email GIF.gif: the seal opens to Prepared for Tesla; linked to https://warmspringshouse.com/4tesla?card=1]

The invitation: warmspringshouse.com/4tesla

Please reach me anytime.

I'm in the demographic most wary of robots and self-driving cars, yet I can't wait for them. I've seen how fragile care can be for the people I love. I want a robot in the loop.

Lisa Wood
208 720 2433
lisa@lisawoodstudio.com
warmspringshouse.com
LISA WOOD STUDIO

No attachment.

## X or Instagram DM

**Message 1:** the video, Warm Springs House - Prepared for Tesla.mp4

**Message 2:**

Hi [First name], Warm Springs House in Boise: the proving ground for the first autonomous corporate residence and entertainment hub. I am delighted to welcome Tesla.

warmspringshouse.com/4tesla

Lisa Wood

